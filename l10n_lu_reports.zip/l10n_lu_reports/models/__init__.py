# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_sales_report
from . import res_partner
from . import res_company
from . import account_financial_report
from . import account_generic_tax_report
from . import ir_attachment
from . import account_coa_report
from . import l10n_lu_yearly_tax_report_manual
from . import l10n_lu_tax_report_data
from . import account_assets_report
from . import account_general_ledger
from . import l10n_lu_yearly_tax_report_appendix
