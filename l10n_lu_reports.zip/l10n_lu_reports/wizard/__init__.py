# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import l10n_lu_generate_xml
from . import l10n_lu_generate_accounts_report
from . import l10n_lu_generate_tax_report
from . import l10n_lu_generate_sales_report
from . import l10n_lu_generate_asset_report
