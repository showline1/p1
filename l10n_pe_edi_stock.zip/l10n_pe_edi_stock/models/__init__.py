# -*- coding: utf-8 -*-
from . import account_edi_format
from . import ir_attachment
from . import l10n_pe_edi_vehicle
from . import stock_picking
