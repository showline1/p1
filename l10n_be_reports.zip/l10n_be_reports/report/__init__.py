# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import l10n_be_281_50_pdf_templates
from . import l10n_be_281_50_xml_templates
from . import l10n_be_325_pdf_templates
