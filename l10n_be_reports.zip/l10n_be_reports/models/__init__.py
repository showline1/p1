# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_report
from . import account_sales_report
from . import partner_vat_listing
from . import res_partner
from . import res_company
from . import account_325_form
from . import account_281_50_form
