# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_move
from . import commission_plan
from . import crm_lead
from . import purchase_order
from . import res_company
from . import res_partner
from . import sale_order
