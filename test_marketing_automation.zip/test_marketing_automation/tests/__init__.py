# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import common
from . import test_flow
from . import test_mailing
from . import test_ma_internals
from . import test_utm
