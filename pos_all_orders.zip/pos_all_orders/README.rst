POS Exchange Order v16
======================
POS Exchange Order

Installation
============
	- www.odoo.com/documentation/16.0/setup/install.html
	- Install our custom addon

Configuration
=============

    No additional configurations needed

Credits
=======
    Developer: Megha v16 @ cybrosys, Contact: odoo@cybrosys.com
