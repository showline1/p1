# -*- coding: utf-8 -*-

from . import test_cl_eightcolumns_report
from . import test_f29_report
