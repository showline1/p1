# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import res_config_settings
from . import social_account
from . import social_media
from . import social_live_post
from . import social_post
from . import social_post_template
from . import social_stream
from . import social_stream_post
