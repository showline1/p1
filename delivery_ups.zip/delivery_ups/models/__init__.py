# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import delivery_ups
from . import stock_package_type
from . import sale
from . import res_partner
