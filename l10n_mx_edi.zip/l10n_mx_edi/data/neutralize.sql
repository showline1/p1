-- disable_l10n_mx_edi_integration
UPDATE res_company
   SET l10n_mx_edi_pac_test_env = true;
