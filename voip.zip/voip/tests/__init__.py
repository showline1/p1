# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_voip_activity
from . import test_voip_user_config
