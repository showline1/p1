# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import voip_queue_mixin  # keep this before res_partner import
from . import mail_activity
from . import res_config_settings
from . import res_partner
from . import res_users
from . import res_users_settings
from . import voip_phonecall
