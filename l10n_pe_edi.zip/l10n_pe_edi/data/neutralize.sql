-- disable l10n_pe edi integration
UPDATE res_company
   SET l10n_pe_edi_test_env = true;
