# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import account_move_line
from . import account_move
from . import ir_attachment
from . import res_company
from . import l10n_pe_edi_certificate
from . import res_config_settings
from . import account_tax
from . import account_tax_group
from . import uom_uom
from . import account_edi_format
from . import account_journal
from . import product_template
from . import mail_template
