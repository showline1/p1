/** @odoo-module **/

const { Component } = owl;

export default class RankingPanel extends Component {}

RankingPanel.template = 'hr_recruitment_reports.RankingPanel';
