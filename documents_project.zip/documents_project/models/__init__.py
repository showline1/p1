# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import document
from . import folder
from . import ir_attachment
from . import project_project
from . import project_task
from . import tags
from . import workflow
