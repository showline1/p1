# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_payroll_employee_departure_holiday_attest
from . import hr_payroll_employee_departure_notice
from . import l10n_be_hr_payroll_schedule_change_wizard
from . import hr_payroll_allocating_paid_time_off
from . import hr_payroll_generate_warrant_payslips
from . import l10n_be_social_balance_sheet
from . import l10n_be_social_security_certificate
from . import l10n_be_eco_vouchers_wizard
from . import l10n_be_double_pay_recovery_wizard
from . import l10n_be_hr_payroll_employee_lang
from . import hr_payroll_payslips_by_employees
from . import l10n_be_december_slip_wizard
from . import l10n_be_group_insurance_wizard
from . import l10n_be_export_sdworx_leaves_wizard
