# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_individual_account_reports
from . import hr_contract_employee_report
from . import hr_281_10_templates
from . import hr_281_45_report
from . import hr_contract_history
from . import l10n_be_work_entry_daily_benefit
from . import l10n_be_social_balance_report
from . import l10n_be_social_security_certificate_report
from . import l10n_be_hr_payroll_274_XX_sheet
from . import l10n_be_hr_payroll_273S_pdf
from . import l10n_be_hr_dmfa_report
from . import hr_payroll_report
