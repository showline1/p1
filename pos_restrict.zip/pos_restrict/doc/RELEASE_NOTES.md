## Module <pos_restrict>

#### 15.10.2022
#### Version 16.0.1.0.0
##### ADD