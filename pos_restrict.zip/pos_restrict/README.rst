POS User Restrict v16
=====================
Restricts User access to pos and orders

Installation
============
	- www.odoo.com/documentation/15.0/setup/install.html
	- Install our custom addon

Configuration
=============

    No additional configurations needed

Credits
=======
    Developer: Risha C.T @ cybrosys, odoo@cybrosys.com
                v16.0 Neenu Merlin Jose @ cybrosys, odoo@cybrosys.com
