# -*- coding: utf-8 -*-
from . import product_product
from . import product_template
from . import res_company
from . import res_config_settings
from . import sale_order
from . import sale_order_line
from . import sale_order_recurrence
