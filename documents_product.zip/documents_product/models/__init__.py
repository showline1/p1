# -*- coding: utf-8 -*-

from . import product_product
from . import product_template
from . import res_config_settings
from . import workflow
from . import res_company
