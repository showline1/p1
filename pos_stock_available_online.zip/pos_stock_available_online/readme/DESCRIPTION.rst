This module allows to display product quantities in selected locations in real time. Quantities are displayed directly on product tiles:
  .. image:: ../static/img/pos_quantity.png

Once a product quantity is changed it will be simultaneously updated in all active POS.

This module depends on stock_available module which is available in https://github.com/OCA/stock-logistics-availability repo.
