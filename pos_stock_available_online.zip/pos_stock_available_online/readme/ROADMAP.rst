This module requires connection to update quantities and doesn't support offline mode.
Warehouses must belong to the same company as POS.
Offline mode support (probably additional module).
