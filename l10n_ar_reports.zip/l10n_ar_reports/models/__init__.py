# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import l10n_ar_vat_book
from . import res_config_settings
from . import res_company
