# -*- coding: utf-8 -*-

from . import hr_contract
from . import hr_employee
from . import res_users
from . import hr_plan_activity_type
