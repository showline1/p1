# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import res_company
from . import res_partner
from . import project_project
from . import project_task
from . import res_config_settings
from . import ir_ui_menu
