# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details

from . import common
from . import test_basic_features_settings
from . import test_fsm_flow
from . import test_industry_fsm_ui
from . import test_project_milestone
from . import test_auto_create_fsm_project
from . import test_fsm_task_analysis
