# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_push_subscription_internals
from . import test_social_push_notifications
from . import test_website_visitor
from . import test_social_push_notifications_image
