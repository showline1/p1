# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import mrp_bom
from . import mrp_mps
from . import product_product
from . import product_template
from . import purchase_order
from . import res_company
from . import res_config_settings
from . import stock_rule
