# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import product_template
from . import sale_order
