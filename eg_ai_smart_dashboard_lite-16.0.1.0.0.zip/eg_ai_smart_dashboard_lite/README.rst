=================================
All in One Dashboard lite
=================================
This app will allow user to custom dashboard with more than 10 charts and custom size and theme.


