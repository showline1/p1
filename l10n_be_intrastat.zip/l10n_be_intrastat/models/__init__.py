# -*- coding: utf-8 -*-

from . import res_config_settings
from . import account_intrastat_report
