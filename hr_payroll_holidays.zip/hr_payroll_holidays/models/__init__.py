#-*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import res_company
from . import hr_leave
from . import res_config_settings
from . import hr_payslip
from . import mail_activity
