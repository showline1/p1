# -*- coding: utf-8 -*-

from . import account_intrastat_code
from . import res_company
from . import res_country
from . import account_move
from . import product
from . import account_intrastat_report
from . import res_config_settings
