# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import chatbot_script
from . import chatbot_script_step
from . import helpdesk
from . import res_users
