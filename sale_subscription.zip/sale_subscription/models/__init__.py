# -*- coding: utf-8 -*-

from . import account_analytic_account
from . import account_move
from . import account_move_line
from . import payment_provider
from . import payment_token
from . import payment_transaction
from . import product
from . import product_pricing
from . import res_partner
from . import sale_order_alert
from . import sale_order_close_reason
from . import sale_order_stage
from . import sale_order_line
from . import sale_order_log
from . import sale_order
from . import sale_order_template
