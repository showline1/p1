# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import crm_lead_convert2ticket
from . import helpdesk_ticket_to_lead
