# -*- coding: utf-8 -*-

from . import product_pricelist
from . import product_pricing
from . import product_product
from . import product_template
from . import sale_order
from . import sale_order_line
from . import sale_order_recurrence
