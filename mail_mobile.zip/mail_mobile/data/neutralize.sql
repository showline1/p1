DELETE FROM ir_config_parameter
 WHERE key IN ('odoo_ocn.project_id', 'ocn.uuid');
