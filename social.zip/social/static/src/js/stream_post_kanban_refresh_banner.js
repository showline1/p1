/** @odoo-module **/

const { Component } = owl;

export class NewContentRefreshBanner extends Component {}

NewContentRefreshBanner.template = 'social.NewContentRefreshBanner';
