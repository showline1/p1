/** @odoo-module **/

import { Dialog } from "@web/core/dialog/dialog";

const { Component } = owl;

export class ImagesCarouselDialog extends Component {}

ImagesCarouselDialog.components = { Dialog };
ImagesCarouselDialog.template = "social.ImagesCarouselDialog";
