/** @odoo-module **/

import { addModelNamesToFetch } from '@bus/../tests/helpers/model_definitions_helpers';

addModelNamesToFetch(['approval.request', 'approval.approver']);
