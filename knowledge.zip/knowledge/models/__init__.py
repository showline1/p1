# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import knowledge_article_favorite
from . import knowledge_article_member
from . import knowledge_article
from . import knowledge_cover
from . import res_partner
from . import res_users
