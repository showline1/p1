# -*- coding: utf-8 -*-

from . import hr_contract
from . import res_company
from . import res_config_settings
