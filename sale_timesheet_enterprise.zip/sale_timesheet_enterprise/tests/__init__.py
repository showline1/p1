# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_invoice_timesheet
from . import test_project_sharing
from . import test_sale_validated_timesheet
from . import test_multicompany
