===============
 Customer Chat
===============

Demo installation
=================

* Install *Automated Action Rules* (`base_automation`) module
* `Install <https://odoo-development.readthedocs.io/en/latest/odoo/usage/install-module.html>`__ this module in a usual way

Demo usage
==========

* Open *Discuss* menu
* Send any message to *Echo Chat (Demo)*

RESULT: your message will be echoed back to you
