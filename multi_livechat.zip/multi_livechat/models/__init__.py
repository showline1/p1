# License MIT (https://opensource.org/licenses/MIT).
from . import mail_channel
from . import res_users
from . import demo
from . import res_partner
