from . import test_l10n_cl_edi_account_move
