Remove Orders in POS
====================
Remove each lines from selected order by simply clicking X button or clear all order with a single click.

Configuration
=============
* No additional configurations needed

License
-------
Odoo Proprietary License v1.0 (OPL-1)
(https://www.odoo.com/documentation/user/12.0/legal/licenses/licenses.html)

Company
-------
* `Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
* Developer:
    Muhammed Nishad T K @cybrosys
    Version 13: Nimisha Murali@cybrosys
    Version 14: Sonu Soman K P @cybrosys
    Version 15: Swapna V @cybrosys
    Version 16: Neenu Merlin Jose@cybrosys

Contacts
--------
* Mail Contact : odoo@cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com

Further information
===================
HTML Description: `<static/description/index.html>`__

