## Module <pos_products_based_on_time>

#### 20.02.2023
#### Version 16.0.1.0.0
#### ADD

- Initial commit for PoS Happy Hours | PoS Time Based Products | PoS Breakfast Lunch Dinner
