/** @odoo-module **/

import tour from 'web_tour.tour';
import '@hr_payroll/js/tours/hr_payroll';

delete tour.tours['payroll_tours'];
