# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import amazon_account
from . import amazon_marketplace
from . import amazon_offer
from . import crm_team
from . import product_product
from . import product_template
from . import res_config_settings
from . import res_partner
from . import sale_order
from . import sale_order_line
from . import stock_location
from . import stock_picking
