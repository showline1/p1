/** @odoo-module */

import { registerTemplateTour } from "@documents_spreadsheet/../tests/utils/tour";

registerTemplateTour("spreadsheet_template_features", "Template with special characters");
