# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import l10n_be_281_10
from . import l10n_be_281_45
from . import hr_payslip
from . import l10n_be_individual_account
