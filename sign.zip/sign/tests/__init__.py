# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

# import tests
from . import test_access_right
from . import test_sign_template
from . import sign_request_common
from . import test_sign_request
from . import test_sign_multicompany
from . import test_ui
from . import test_sign_controllers
