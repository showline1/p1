# -*- coding: utf-8 -*-
{
    'name': "Account Avatax - Ecommerce",
    'category': 'Accounting/Accounting',
    'depends': ['account_avatax_sale', 'website_sale'],
    'data': ['views/templates.xml'],
    'auto_install': True,
    'license': 'OEEL-1',
}
