# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details

from . import test_hr
from . import test_form
from . import test_recurrency
from . import test_resource
from . import test_planning
from . import test_publication
from . import test_user_access
from . import test_period_duplication
from . import test_ui
