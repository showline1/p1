* Ooops404 <https://ooops404.com>

  * Ilyas <irazor147@gmail.com>

* `Acsone <https://www.acsone.eu/>`_:

  * Maxime Franco
