# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import timesheet_grid_mixin
from . import analytic
from . import hr_employee
from . import ir_module
from . import project
from . import res_config_settings
from . import res_company
from . import res_users
from . import task
