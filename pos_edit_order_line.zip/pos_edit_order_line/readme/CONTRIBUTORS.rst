* Ooops404 <https://www.ooops404.com/>
* Cetmix <https://cetmix.com/>
* `Acsone <https://www.acsone.eu/>`_:

  * Maxime Franco
