Select PoS > configuration > enable flag "Allow Edit Order Line"
To improve usability when there are more than 3 order lines, we suggest activating the "Large scrollbars" POS setting.
