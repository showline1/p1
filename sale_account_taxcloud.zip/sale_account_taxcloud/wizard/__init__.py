# -*- coding: utf-8 -*-

from . import sale_make_invoice_advance
