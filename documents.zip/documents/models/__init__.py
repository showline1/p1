# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import mail_activity
from . import mail_activity_type
from . import ir_attachment
from . import ir_binary
from . import document
from . import documents_mixin
from . import folder
from . import res_partner
from . import res_users
from . import share
from . import tags
from . import workflow
